import com.sap.it.api.mapping.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime


/* Set the max length of input, if input value's length is greate than maxLength, get the substring*/

def String setMaxLength(String inputValue, int maxLength) {
    if (inputValue.length() >= maxLength) {
        return inputValue.substring(0, maxLength)
    }
    return inputValue
}

def formatDDMYYYY(String dateString) {

    def outputFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    def date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"))
    return  date.format(outputFormat)
}



/*
    Get Interface Runtime with format: 08-MAY-2023 14.44.36.000000000
 */
def String getInterfaceRuntime() {
    DateTimeFormatter formatterDateTime = DateTimeFormatter.ofPattern( 'dd-MMM-yyyy hh.mm.ss.000000000' )
    LocalDateTime dateTime = LocalDateTime.now()
    return  dateTime.format(formatterDateTime)
}
